import random
import pygame

class Monster(pygame.sprite.Sprite):
    def __init__(self, x, y, image_file, speed, sight_radius, damage):
        super().__init__()
        self.image = pygame.image.load(image_file).convert_alpha()
        self.image = pygame.transform.scale(self.image, (48, 48))
        self.rect = self.image.get_rect(center=(x, y))
        self.x = x
        self.y = y
        self.speed = speed
        self.sight_radius = sight_radius
        self.damage = damage
        # random richtung
        self.direction_x = random.choice([-1, 0, 1])
        self.direction_y = random.choice([-1, 0, 1])
        self.change_timer = 1.5

    def update(self, dt, play_area, player):
        player_pos = pygame.Vector2(player.rect.center)
        my_pos = pygame.Vector2(self.x, self.y)
        direction = player_pos - my_pos

        if 0 < direction.length() < self.sight_radius:
            direction = direction.normalize()
            self.x += direction.x * self.speed * dt
            
            self.y += direction.y * self.speed * dt
        else:
            self.x += self.direction_x * self.speed * dt
            self.y += self.direction_y * self.speed * dt
            self.change_timer -= dt
            if self.change_timer <= 0:
                self.direction_x = random.choice([-1, 0, 1])
                self.direction_y = random.choice([-1, 0, 1])
                self.change_timer = 1.5


        self.rect.center = (self.x, self.y)


        if not play_area.contains(self.rect):
            self.direction_x = -self.direction_x
            self.direction_y = -self.direction_y
            self.rect.clamp_ip(play_area)
            self.x = self.rect.centerx
            self.y = self.rect.centery







class CardioGhost(Monster):
    def __init__(self, x, y):
        super().__init__(x, y, "assets/cradioghost.png", 175, 200, 5)

class DeadLiftDemon(Monster):
    def __init__(self, x, y):
        super().__init__(x, y, "assets/deadliftdemon.png", 150, 200, 10)

class LegDayMonster(Monster):
    def __init__(self, x, y):
        super().__init__(x, y, "assets/legdaymonster.png", 200, 250, 15)