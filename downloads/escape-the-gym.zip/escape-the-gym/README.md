# Escape the Gym

Ein 2D-Spiel mit Python und pygame-ce, mein Projekt im BBC-Modul «Einstieg Programmierung».

Du bist im Gym eingesperrt und musst **100 Power** sammeln, damit die Tür aufgeht. Power bekommst du an den Geräten. Aber im Gym laufen drei Monster herum, und wenn sie dich erwischen, verlierst du Power. Schaffst du es raus, landest du mit deiner Zeit im Leaderboard.

## Features

**Muss-Kriterien (alle erledigt)**

- [x] Spielfigur bewegt sich mit WASD / Pfeiltasten und bleibt im Gym
- [x] An den Geräten bekommt man Power, wenn man E (oder Space) gedrückt hält
- [x] 3 Monster laufen zufällig herum und verfolgen dich im Sichtradius
- [x] Berührt dich ein Monster, verlierst du Power (jedes Monster unterschiedlich viel)
- [x] Die aktuelle Power wird oben rechts angezeigt
- [x] Bei 100 Power geht die Tür auf und du kannst entkommen

**Extras (nicht im Antrag geplant)**

- [x] Startscreen mit Steuerung und Ziel
- [x] Name eingeben im Startscreen
- [x] Zeit wird gemessen und angezeigt
- [x] Leaderboard (Top 5) wird in `leaderboard.json` gespeichert, mit «Time to beat» im Startscreen
- [x] Space funktioniert wie E (Feedback von einem Kollegen, ist so einfacher)

**Wunsch-Kriterien (aus Zeitgründen nicht gemacht - werde zuhause in ferien machen auf der seite :-)**

- [ ] Protein Shake: nächste Übung gibt +25 % Power
- [ ] Energy Drink: kurze Zeit schneller laufen
- [ ] Neustart mit Taste R
- [ ] Sounds und Hintergrundmusik

## So startest du das Spiel

Du brauchst Python 3.14 und pygame-ce.

```bash
pip install -r requirements.txt
python main.py
```

Wichtig: Starte das Spiel im Projektordner, sonst findet es die Bilder im Ordner `assets` nicht.

## Steuerung

| Taste | Was passiert |
|---|---|
| Buchstaben / Zahlen | Name eingeben (Startscreen) |
| Enter | Spiel starten |
| WASD / Pfeiltasten | Bewegen |
| E oder Space (halten) | An einem Gerät Power sammeln |
| X | Spiel beenden (nicht im Startscreen, da tippst du ja deinen Namen) |

## Die Monster

| Monster | Tempo | Sichtradius | Schaden |
|---|---|---|---|
| Cardio Ghost | 175 | 300 | 1 |
| Deadlift Demon | 250 | 200 | 4 |
| Leg Day Monster | 210 | 250 | 2 |

Alle drei erben von der Klasse `Monster` und geben nur ihre eigenen Werte mit.

## Projektstruktur

```
main.py          Game Loop, Startscreen, Zeichnen
player.py        Klasse Player (Bewegung, Power, Schaden)
station.py       Klasse Station (Power sammeln)
door.py          Klasse Door (öffnet bei 100 Power)
monster.py       Klasse Monster + CardioGhost, DeadLiftDemon, LegDayMonster
leaderboard.py   Leaderboard laden und speichern (JSON)
assets/          Bilder und Schrift
```

## Was ich gelernt habe

- Eine Game Loop aufbauen: Events, Update, Zeichnen
- Mit `dt` rechnen, damit das Spiel auf jedem PC gleich schnell ist
- OOP mit Klassen, Attributen, Methoden und Vererbung
- `Vector2`, damit die Monster mich verfolgen können
- Daten in einer JSON-Datei speichern und wieder laden
- Bugs finden und fixen, z.B. `and` / `or` ohne Klammern oder `continue` an der falschen Stelle

## Credits

Die Pixel-Art-Figuren hat meine Schwester **Zaara** in Piskel gezeichnet. Sie wollte unbedingt Credit dafür :-)

Schrift: [Press Start 2P](https://fonts.google.com/specimen/Press+Start+2P) (Google Fonts).

## Leaderboard (Stand Abgabe)

| Platz | Name | Zeit |
|---|---|---|
| 1 | NEVIO | 8.25 s |
| 2 | AYAAAAAN | 11.0 s |
| 3 | TEST | 11.2 s |
| 4 | AYAAN2 | 15.7 s |
| 5 | AYAAN | 24.8 s |


