import pygame

class Station(pygame.sprite.Sprite):
    def __init__(self, x, y, image_file, name, power_value):
        super().__init__()
        self.image = pygame.image.load(image_file).convert_alpha()
        self.image = pygame.transform.scale(self.image, (75, 75))
        self.rect = self.image.get_rect(center=(x, y))
        self.name = name
        self.power_value = power_value

    def update(self, dt, player):
         keys = pygame.key.get_pressed()
         if player.rect.colliderect(self.rect) and (keys[pygame.K_e] or keys[pygame.K_SPACE]):
            player.power += self.power_value * dt
