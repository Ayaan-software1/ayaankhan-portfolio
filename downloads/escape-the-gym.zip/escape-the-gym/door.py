import pygame

class Door(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.closed = pygame.image.load('assets/door_closed.png').convert_alpha()
        self.opened = pygame.image.load('assets/door_open.png').convert_alpha()
        self.closed = pygame.transform.scale(self.closed, (48, 60))
        self.opened =  pygame.transform.scale(self.opened, (48, 60))
        self.image_closed = self.closed
        self.image_opened = self.opened
        self.image = self.image_closed
        self.rect = self.image.get_rect(midbottom=(x, y))

        self.is_open = False

    def update(self, player):
        if player.power >= 100 :
            self.is_open = True
            self.image = self.image_opened
        else:
            self.is_open = False
            self.image = self.image_closed

    def player_escaped(self, player):
        if self.is_open and self.rect.colliderect(player.rect):
            return True
        return False