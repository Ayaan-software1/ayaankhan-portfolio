import pygame

from leaderboard import load_leaderboard, save_score
from player import Player
from station import Station
from door import Door
from monster import CardioGhost
from monster import DeadLiftDemon
from monster import LegDayMonster



WIDTH = 960
HEIGHT = 640
FPS = 60

pygame.init()

pygame.display.set_caption("Gym Escape")
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

background = pygame.image.load("assets/gym_floor.png").convert()
player = Player(WIDTH/2, HEIGHT/2)
play_area = pygame.Rect(8, 60, WIDTH - 16, HEIGHT - 68)  # x = 8, y = 60. von breite 8 auf beide Seiten weg und von unten
# nur 8, weil unser y schon 60 vo xxn oben genommen hat
stations = [
    Station(200, 200, "assets/legpress.png", "Beinpresse", 15),
    Station(500, 500, "assets/latpulldown.png", "Beinpresse", 20),
    Station(760, 250, "assets/squatrack.png", "Beinpresse", 15),
]
monsters = [
    CardioGhost(700, 400),
    DeadLiftDemon(400, 500),
    LegDayMonster(200, 500)
]
start_screen = pygame.image.load("assets/start_screen.png").convert()
game_state = "start"
player_name = ""
run_time = 0
score_saved = False
leaderboard = load_leaderboard()


door = Door(668, 66 )
game_won = False
escape_screen = pygame.image.load("assets/escape_screen.png").convert()
font = pygame.font.Font("assets/PressStart2P-Regular.ttf", 20)
running = True
while running:
    dt = clock.tick(FPS) / 1000

    # 1. Events gelesen
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and game_state == "start":
            if event.key == pygame.K_BACKSPACE:
                player_name = player_name[:-1]
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and player_name != "":
                game_state = "playing"
            elif event.unicode.isalnum() and len(player_name) < 10:
                player_name += event.unicode.upper()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_x and game_state != "start":
            running = False


    if game_state == "start":
        screen.blit(start_screen, (0, 0))
        name_text = font.render(f"NAME: {player_name}_", True, "yellow")
        screen.blit(name_text, name_text.get_rect(center=(480, 585)))
        if leaderboard:
            best_text = font.render(f"TIME TO BEAT: {leaderboard[0]['time']}s", True, "white")
            screen.blit(best_text, best_text.get_rect(center=(480, 618)))
        pygame.display.flip()
        continue

    #update


    player.update(dt, play_area)
    if not game_won:
        run_time += dt
    if door.player_escaped(player):
        game_won = True
    if game_won and not score_saved:
        leaderboard = save_score(player_name, run_time)
        score_saved = True
    for station in stations:
        station.update(dt, player)
    if player.power > 100 :
        player.power = 100

    for monster in monsters:
        monster.update(dt, play_area, player)
        if monster.rect.colliderect(player.rect):
            player.take_damage(monster.damage)
    door.update(player)


    screen.blit(background, (0, 0))  #hier wird unser background displayed
    screen.blit(door.image, door.rect)
    for station in stations:
        screen.blit(station.image, station.rect)
    for monster in monsters:
        screen.blit(monster.image, monster.rect)
    screen.blit(player.image, player.rect)
    power_text = font .render(f"POWER: {int(player.power)}", True, "yellow")
    screen.blit(power_text, (760, 20))
    time_text = font.render(f"TIME: {run_time:.1f}", True, "white")
    screen.blit(time_text, (20, 20))
    if game_won:
        screen.blit(escape_screen, (0, 0))
        pygame.draw.rect(screen, "black", (500, 462, 440, 170))
        title_text = font.render("TOP 5", True, "yellow")
        screen.blit(title_text, (520, 477))
        for i, entry in enumerate(leaderboard):
            line = font.render(f"{i + 1}. {entry['name']} {entry['time']}s", True, "white")
            screen.blit(line, (520, 512 + i * 24))
    pygame.display.flip()

pygame.quit()