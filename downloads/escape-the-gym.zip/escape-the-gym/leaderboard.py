import json

FILE = "leaderboard.json"

def load_leaderboard():
    try:
        with open(FILE, "r") as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_score(name, time):
    leaderboard = load_leaderboard()
    leaderboard.append({"name": name, "time": round(time, 1)})
    leaderboard.sort(key=lambda entry: entry["time"])
    leaderboard = leaderboard[:5]
    with open(FILE, "w") as file:
        json.dump(leaderboard, file, indent=3)
    return leaderboard
