import pygame


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("assets/player.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (48, 48))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 300
        self.power = 0
        self.hit_timer = 0

    def update(self, dt, play_area):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.rect.x -= self.speed * dt
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.rect.x += self.speed * dt
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.rect.y -= self.speed * dt
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.rect.y += self.speed * dt

        self.rect.clamp_ip(play_area)
        if self.hit_timer > 0:
            self.hit_timer -= dt



    def take_damage(self, damage):
        if self.hit_timer > 0:
            return
        self.power -= damage
        if self.power < 0:
            self.power = 0
        self.hit_timer = 0.275
